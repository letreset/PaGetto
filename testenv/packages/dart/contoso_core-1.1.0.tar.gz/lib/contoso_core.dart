/// Shared primitives used by all Contoso Dart packages.
library;

const version = '1.1.0';
