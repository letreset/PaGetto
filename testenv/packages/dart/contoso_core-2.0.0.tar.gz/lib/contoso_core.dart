/// Shared primitives used by all Contoso Dart packages.
library;

const version = '2.0.0';
