/// HTTP client defaults for Contoso services.
library;

const version = '1.0.0';
