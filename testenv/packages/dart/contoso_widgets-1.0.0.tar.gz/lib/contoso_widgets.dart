/// Flutter widgets in the Contoso design language.
library;

const version = '1.0.0';
